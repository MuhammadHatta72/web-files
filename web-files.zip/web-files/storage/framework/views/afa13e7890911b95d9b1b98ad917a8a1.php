;

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
    
    <li class="nav-item <?php echo e(request()->is('*arsip_travels*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('arsip_travels.index')); ?>" class="nav-link">
            <i class="fas fa-file"></i><span>Arsip Travel</span>
        </a>
    </li>
    <li class="nav-item <?php echo e(request()->is('*arsip_expen_reports*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('arsip_expen_reports.index')); ?>" class="nav-link">
            <i class="fas fa-file"></i><span>Arsip Expen Report</span>
        </a>
    </li>
    <li class="nav-item <?php echo e(request()->is('*arsip_advances*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('arsip_advances.index')); ?>" class="nav-link">
            <i class="fas fa-file"></i><span>Arsip Advance</span>
        </a>
    </li>
    <li class="nav-item <?php echo e(request()->is('*travel_authorizations*') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('travel_authorizations.index')); ?>" class="nav-link">
            <i class="fas fa-file"></i><span>Travel Authorization</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pomitrav/web-files/resources/views/layouts/sidebar_admin.blade.php ENDPATH**/ ?>