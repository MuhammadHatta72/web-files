<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Selamat Datang! <?php echo e(auth()->user()->admin->nama); ?></h1>
        </div>

        <?php if(session('password_warning')): ?>
            <script>
                Swal.fire({
                    icon: 'warning',
                    title: 'Peringatan',
                    text: 'Silahkan ubah password anda terlebih dahulu',
                    showCancelButton: true,
                    confirmButtonText: 'Ubah Password Sekarang',
                    cancelButtonText: 'Ubah Nanti',
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '<?php echo e(route('profile.edit')); ?>';
                    }
                });
            </script>
        <?php endif; ?>

        <div class="section-body">
            <div class="row">
                <div class="col-lg-12 mb-4 shadow p-3">
                    <img src="<?php echo e(asset('assets/landing/img/carousel-1.jpg')); ?>" alt="carousel" class="img-fluid">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-xl-3 mb-4">
                    <div class="card bg-warning text-white">
                        <div class="card-body py-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="me-3">
                                    <div>
                                        <h5>Arsip Travel</h5>
                                    </div>
                                    <div class="h4 font-weight-600 text-white"><?php echo e($count_arsip_travel); ?></div>
                                </div>
                                <i class="fas fa-envelope-open-text" style="font-size:xx-large"></i>
                            </div>
                        </div>
                        <div class="card-footer py-2 d-flex align-items-center justify-content-between small shadow-dark">
                            <a class="text-white stretched-link" href="<?php echo e(route('arsip_travels.index')); ?>">
                                <h6>Detail</h6>
                            </a>
                            <div class="text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-xl-3 mb-4">
                    <div class="card bg-info text-white">
                        <div class="card-body py-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="me-3">
                                    <div>
                                        <h5>Arsip Expen Report</h5>
                                    </div>
                                    <div class="h4 font-weight-600 text-white"><?php echo e($count_arsip_expen_report); ?></div>
                                </div>
                                <i class="fas fa-envelope-open-text" style="font-size:xx-large"></i>
                            </div>
                        </div>
                        <div class="card-footer py-2 d-flex align-items-center justify-content-between small shadow-dark">
                            <a class="text-white stretched-link" href="<?php echo e(route('arsip_expen_reports.index')); ?>">
                                <h6>Detail</h6>
                            </a>
                            <div class="text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-xl-3 mb-4">
                    <div class="card bg-primary text-white">
                        <div class="card-body py-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="me-3">
                                    <div>
                                        <h5>Arsip Advance</h5>
                                    </div>
                                    <div class="h4 font-weight-600 text-white"><?php echo e($count_arsip_advance); ?></div>
                                </div>
                                <i class="fas fa-envelope-open-text" style="font-size:xx-large"></i>
                            </div>
                        </div>
                        <div class="card-footer py-2 d-flex align-items-center justify-content-between small shadow-dark">
                            <a class="text-white stretched-link" href="<?php echo e(route('arsip_advances.index')); ?>">
                                <h6>Detail</h6>
                            </a>
                            <div class="text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-xl-3 mb-4">
                    <div class="card bg-success text-white">
                        <div class="card-body py-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="me-3">
                                    <div>
                                        <h5>Travel Authorization</h5>
                                    </div>
                                    <div class="h4 font-weight-600 text-white"><?php echo e($count_travel_authorization); ?></div>
                                </div>
                                <i class="fas fa-envelope-open-text" style="font-size:xx-large"></i>
                            </div>
                        </div>
                        <div class="card-footer py-2 d-flex align-items-center justify-content-between small shadow-dark">
                            <a class="text-white stretched-link" href="<?php echo e(route('travel_authorizations.index')); ?>">
                                <h6>Detail</h6>
                            </a>
                            <div class="text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pomitrav/web-files/resources/views/dashboard/admin.blade.php ENDPATH**/ ?>