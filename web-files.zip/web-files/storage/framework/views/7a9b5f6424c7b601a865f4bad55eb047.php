<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
        <a href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('assets/img/logo-tf.png')); ?>" alt="logo" width="150" class="img-fluid">
        </a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
        <a href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('assets/img/logo-tf.png')); ?>" alt="logo" width="100" class="img-fluid">
        </a>
    </div>
    <ul class="sidebar-menu">

        <?php $__env->startSection('sidebar'); ?>

            <li class="menu-header">Menu</li>
            <li class="nav-item <?php echo e(request()->is('home') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('home')); ?>" class="nav-link">
                    <i class="fas fa-poll-h"></i><span>Dashboard</span>
                </a>
            </li>
        <?php echo $__env->yieldSection(); ?>
    </ul>

    <div class="mt-4 mb-4 p-2 hide-sidebar-mini">
        <a href="/" target="_blank" class="btn btn-primary btn-lg btn-block btn-icon-split">
            <img src="<?php echo e(asset('assets/img/logo-tf.png')); ?>" alt="logo" width="100" class="img-fluid">
            WEBSITE
        </a>
    </div>
</aside>
<?php /**PATH /home/pomitrav/web-files/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>