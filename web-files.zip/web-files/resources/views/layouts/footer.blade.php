<div class="footer-left">
    Copyright &copy; 2024
    <div class="bullet"></div>
</div>
<div class="footer-right">0.1</div>
